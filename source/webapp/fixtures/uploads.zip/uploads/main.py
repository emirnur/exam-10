import socketserver
from server import ThreadedTcpServer
from request import Request
from response import Response

HOST = '127.0.0.1'
PORT = 8000


class MyTCPHandler(socketserver.StreamRequestHandler):
    def handle(self):
        print('Connected from: ' + str(self.client_address))

        response = Response(self.wfile)
        request = Request(self.rfile)
        response.add_header('Connection', 'close')

        first_page = "<h1>First page</h1>"
        second_page = "<h1>Second page</h1>"
        third_page = "<h1>Third page</h1>"
        error_page = '<h1> Not found</h1>'
        if request.path == "/":
            response.set_body('<a href="/one">First page</a><br/>'
                              '<a href="/two">Second page</a><br/>'
                              '<a href="/three">Third page</a><br/>')
        elif request.path == "/one" and request.method == "GET":
            response.set_body(first_page)
        elif request.path == "/two" and request.method == "GET":
            response.set_body(second_page)
        elif request.path == "/three" and request.method == "GET":
            response.set_body(third_page)
        else:
            response.add_header('Content-Type', 'text/html')
            response.add_header('Connection', 'close')
            response.set_status(Response.HTTP_NOT_FOUND)
            response.set_body(error_page)
        response.send()


ThreadedTcpServer.allow_reuse_address = True
with ThreadedTcpServer((HOST, PORT), MyTCPHandler) as server:
    server.serve_forever()
